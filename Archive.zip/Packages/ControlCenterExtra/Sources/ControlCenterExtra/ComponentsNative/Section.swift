//
//  File.swift
//  
//
//  Created by Sake Salverda on 18/03/2024.
//

import SwiftUI

//struct SectionMenuStyle: SectionStyle {
//    
//}
//
//#Preview {
//    Text("Test")
//}

//
//  PreviewHack.swift
//  PowerMode
//
//  Created by Sake Salverda on 08/12/2023.
//

//  This file is used to "preview" the widget on the desktop

import SwiftUI

struct PreviewHackView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    PreviewHackView()
}
